#include "StdAfx.h"
#include "complejo.h"


complejo::complejo(void){}
complejo::complejo(double r, double i)
	{real=r;
    imag =i;}
void complejo::Set_real (double  r)
        {real=r;}
 void complejo::Set_imag (double  i)
	{imag=i;}
 double complejo::Get_real()
	 {return real;}
 double complejo::Get_imag()
    {return imag;}
 void complejo::suma(const complejo a,const complejo b)
	 {real =a.real+b.real;
      imag=a.imag + b.imag;}


