#pragma once

 class complejo
{private:
  double real ;
  double imag;

public:
	complejo(void);
	complejo (double r, double i);
	void Set_real (double  r);
    void Set_imag (double  i);
	double Get_real();
	double Get_imag();
	void suma (complejo a ,complejo b);
};

