#pragma once

namespace AreaCuadrado {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::TextBox^  txtlado;
	private: System::Windows::Forms::TextBox^  txtarea;
	private: System::Windows::Forms::Button^  btbcalcular;
	protected: 



	private: System::Windows::Forms::Label^  label2;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->txtlado = (gcnew System::Windows::Forms::TextBox());
			this->txtarea = (gcnew System::Windows::Forms::TextBox());
			this->btbcalcular = (gcnew System::Windows::Forms::Button());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label1->Location = System::Drawing::Point(41, 49);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(46, 23);
			this->label1->TabIndex = 0;
			this->label1->Text = L"Lado";
			this->label1->TextAlign = System::Drawing::ContentAlignment::MiddleCenter;
			// 
			// txtlado
			// 
			this->txtlado->Location = System::Drawing::Point(128, 49);
			this->txtlado->Name = L"txtlado";
			this->txtlado->Size = System::Drawing::Size(100, 20);
			this->txtlado->TabIndex = 1;
			this->txtlado->TextChanged += gcnew System::EventHandler(this, &Form1::txtlado_TextChanged);
			// 
			// txtarea
			// 
			this->txtarea->Location = System::Drawing::Point(128, 134);
			this->txtarea->Name = L"txtarea";
			this->txtarea->Size = System::Drawing::Size(100, 20);
			this->txtarea->TabIndex = 2;
			// 
			// btbcalcular
			// 
			this->btbcalcular->BackColor = System::Drawing::SystemColors::MenuHighlight;
			this->btbcalcular->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->btbcalcular->ForeColor = System::Drawing::SystemColors::ControlText;
			this->btbcalcular->Location = System::Drawing::Point(128, 232);
			this->btbcalcular->Name = L"btbcalcular";
			this->btbcalcular->Size = System::Drawing::Size(100, 32);
			this->btbcalcular->TabIndex = 3;
			this->btbcalcular->Text = L"Calcular";
			this->btbcalcular->UseVisualStyleBackColor = false;
			this->btbcalcular->Click += gcnew System::EventHandler(this, &Form1::btbcalcular_Click);
			// 
			// label2
			// 
			this->label2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->label2->Location = System::Drawing::Point(41, 134);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(46, 23);
			this->label2->TabIndex = 4;
			this->label2->Text = L"Area";
			this->label2->TextAlign = System::Drawing::ContentAlignment::MiddleCenter;
			this->label2->Click += gcnew System::EventHandler(this, &Form1::label2_Click);
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(806, 396);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->btbcalcular);
			this->Controls->Add(this->txtarea);
			this->Controls->Add(this->txtlado);
			this->Controls->Add(this->label1);
			this->Name = L"Form1";
			this->Text = L"AreaCuadrado";
			this->Load += gcnew System::EventHandler(this, &Form1::Form1_Load);
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void Form1_Load(System::Object^  sender, System::EventArgs^  e) {
			 }
	private: System::Void label2_Click(System::Object^  sender, System::EventArgs^  e) {
			 }
private: System::Void btbcalcular_Click(System::Object^  sender, System::EventArgs^  e) {
			 int lado, Area;
			 lado = System::Convert::ToInt32(txtlado->Text);
			 Area = lado * lado;
			 txtarea->Text=Area.ToString();
		 }
private: System::Void txtlado_TextChanged(System::Object^  sender, System::EventArgs^  e) {
		 }
};
}

