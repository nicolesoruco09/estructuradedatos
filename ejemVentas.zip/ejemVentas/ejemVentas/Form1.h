#pragma once
#include "iostream"
#include "venta.h"
#include <string>
#include "msclr\marshal_cppstd.h"
namespace ejemVentas {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace std;
	using namespace msclr;

	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::TextBox^  txtPrecio1;
	protected: 
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::TextBox^  txtCantidad1;
	private: System::Windows::Forms::Label^  label4;
	private: System::Windows::Forms::TextBox^  txtCantidad2;
	private: System::Windows::Forms::Label^  label5;
	private: System::Windows::Forms::Label^  label6;
	private: System::Windows::Forms::TextBox^  txtPrecio2;
	private: System::Windows::Forms::Label^  label7;
	private: System::Windows::Forms::TextBox^  txtPagar;
	private: System::Windows::Forms::Button^  btnCalcular;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->txtPrecio1 = (gcnew System::Windows::Forms::TextBox());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->txtCantidad1 = (gcnew System::Windows::Forms::TextBox());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->txtCantidad2 = (gcnew System::Windows::Forms::TextBox());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->label6 = (gcnew System::Windows::Forms::Label());
			this->txtPrecio2 = (gcnew System::Windows::Forms::TextBox());
			this->label7 = (gcnew System::Windows::Forms::Label());
			this->txtPagar = (gcnew System::Windows::Forms::TextBox());
			this->btnCalcular = (gcnew System::Windows::Forms::Button());
			this->SuspendLayout();
			// 
			// txtPrecio1
			// 
			this->txtPrecio1->Location = System::Drawing::Point(118, 40);
			this->txtPrecio1->Name = L"txtPrecio1";
			this->txtPrecio1->Size = System::Drawing::Size(107, 20);
			this->txtPrecio1->TabIndex = 0;
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(11, 12);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(58, 13);
			this->label1->TabIndex = 1;
			this->label1->Text = L"producto 1";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(47, 43);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(36, 13);
			this->label2->TabIndex = 2;
			this->label2->Text = L"precio";
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(47, 69);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(48, 13);
			this->label3->TabIndex = 4;
			this->label3->Text = L"cantidad";
			// 
			// txtCantidad1
			// 
			this->txtCantidad1->Location = System::Drawing::Point(118, 66);
			this->txtCantidad1->Name = L"txtCantidad1";
			this->txtCantidad1->Size = System::Drawing::Size(107, 20);
			this->txtCantidad1->TabIndex = 3;
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Location = System::Drawing::Point(47, 152);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(48, 13);
			this->label4->TabIndex = 9;
			this->label4->Text = L"cantidad";
			// 
			// txtCantidad2
			// 
			this->txtCantidad2->Location = System::Drawing::Point(118, 149);
			this->txtCantidad2->Name = L"txtCantidad2";
			this->txtCantidad2->Size = System::Drawing::Size(107, 20);
			this->txtCantidad2->TabIndex = 8;
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Location = System::Drawing::Point(47, 121);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(36, 13);
			this->label5->TabIndex = 7;
			this->label5->Text = L"precio";
			// 
			// label6
			// 
			this->label6->AutoSize = true;
			this->label6->Location = System::Drawing::Point(11, 90);
			this->label6->Name = L"label6";
			this->label6->Size = System::Drawing::Size(58, 13);
			this->label6->TabIndex = 6;
			this->label6->Text = L"producto 2";
			// 
			// txtPrecio2
			// 
			this->txtPrecio2->Location = System::Drawing::Point(118, 118);
			this->txtPrecio2->Name = L"txtPrecio2";
			this->txtPrecio2->Size = System::Drawing::Size(107, 20);
			this->txtPrecio2->TabIndex = 5;
			// 
			// label7
			// 
			this->label7->AutoSize = true;
			this->label7->Location = System::Drawing::Point(67, 206);
			this->label7->Name = L"label7";
			this->label7->Size = System::Drawing::Size(66, 13);
			this->label7->TabIndex = 11;
			this->label7->Text = L"total a pagar";
			// 
			// txtPagar
			// 
			this->txtPagar->Location = System::Drawing::Point(140, 203);
			this->txtPagar->Name = L"txtPagar";
			this->txtPagar->Size = System::Drawing::Size(107, 20);
			this->txtPagar->TabIndex = 10;
			// 
			// btnCalcular
			// 
			this->btnCalcular->Location = System::Drawing::Point(81, 240);
			this->btnCalcular->Name = L"btnCalcular";
			this->btnCalcular->Size = System::Drawing::Size(166, 44);
			this->btnCalcular->TabIndex = 12;
			this->btnCalcular->Text = L"Calcular";
			this->btnCalcular->UseVisualStyleBackColor = true;
			this->btnCalcular->Click += gcnew System::EventHandler(this, &Form1::btnCalcular_Click);
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(319, 306);
			this->Controls->Add(this->btnCalcular);
			this->Controls->Add(this->label7);
			this->Controls->Add(this->txtPagar);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->txtCantidad2);
			this->Controls->Add(this->label5);
			this->Controls->Add(this->label6);
			this->Controls->Add(this->txtPrecio2);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->txtCantidad1);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->txtPrecio1);
			this->Name = L"Form1";
			this->Text = L"Form1";
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void btnCalcular_Click(System::Object^  sender, System::EventArgs^  e) {
				 venta a,b;
				 a.Set_precio(System::Convert::ToDouble(txtPrecio1->Text));
				 b.Set_precio(System::Convert::ToDouble(txtPrecio2->Text));
				 a.Set_cantidad(System::Convert::ToInt32(txtCantidad1->Text));
				 b.Set_cantidad(System::Convert::ToInt32(txtCantidad2->Text));
				 double sumatotal;
				 sumatotal =a.Get_precio()*a.Get_cantidad()+b.Get_precio()*b.Get_cantidad();
				 txtPagar->Text=System::Convert::ToString(sumatotal);

			 }
};
}

