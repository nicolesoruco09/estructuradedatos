#pragma once
#include "iostream"

 class venta
{
private:
	double precio;
	int cantidad;
	double totalapagar;
public:
	venta(void);
	void Set_precio (float p);
	void Set_cantidad (int c);
	void Set_totalapagar (float t);
	double Get_precio();
	int Get_cantidad();
	double Get_totalapagar();
	void calcular (venta a , venta b);
}; 

