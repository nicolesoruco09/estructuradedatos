#include "StdAfx.h"
#include "venta.h"


venta::venta(void)
{
}
void venta::Set_precio (float p)
{ precio=p;
}
void venta::Set_cantidad (int c)
{cantidad=c;
}
void venta::Set_totalapagar (float t)
{totalapagar=t;
}
double venta::Get_precio()
{return precio;
}
int venta::Get_cantidad()
{return cantidad;
}
double venta::Get_totalapagar()
{return totalapagar;
}
void venta::calcular (venta a , venta b)
{totalapagar=a.precio*a.cantidad+b.precio*b.cantidad;

}