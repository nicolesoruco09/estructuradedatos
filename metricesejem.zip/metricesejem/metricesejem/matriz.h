#pragma once
 class matriz

{private:
 int mat[10][10];
 int n;
 int m;

public:
	matriz(void);
	void cargar();
	bool verifcuadrada;
	void mostrar();
	void mostrardiagonal();
	int sumardiagonal();
	int devolverfila();
	void sumamatrices (matriz mat1;matriz mat2);
};

