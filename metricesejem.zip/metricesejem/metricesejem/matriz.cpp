#include "StdAfx.h"
#include "matriz.h"


matriz::matriz(void)
{
}
