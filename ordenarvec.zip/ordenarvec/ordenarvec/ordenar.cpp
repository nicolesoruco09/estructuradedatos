#include "StdAfx.h"
#include "ordenar.h"


ordenar::ordenar(void)
{ vec[N]=0;
 tamano=0;
}
void ordenar::setvector (float e,int pos)
{vec[pos]=e;
}
float ordenar::getvector (int pos)
{return vec[pos];
}
void ordenar::settamano(int tam)
{tamano= tam;
}
int ordenar::gettamano()
{return tamano;
}
void ordenar::calcular()
{ float aux=0;
for (int i=0;i<tamano-1;i++)
{for (int p=i+1;p<tamano;p++)
{if (vec[i]>vec[p])
	{aux = vec[i];
	vec[i]=vec[p];
	vec[p]=aux;}
}
}
}