#pragma once
#include "iostream"
#define N 40

class ordenar
{
private:
	float vec[N];
	int tamano;
public:
	ordenar(void);
	void setvector (float e,int pos);
	float getvector (int pos);
	void settamano(int tam);
	int gettamano();
	void calcular();
};

