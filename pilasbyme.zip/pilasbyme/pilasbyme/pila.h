#pragma once
#define N 20

 class pila
{private:
 int cima;
int V[N];
public:
	pila(void);
	void apilar (int x);
	int desapilar();
	bool vacio();
	bool lleno();
};

