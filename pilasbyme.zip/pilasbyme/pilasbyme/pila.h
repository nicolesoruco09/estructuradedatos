#pragma once
#define N 20

 class pila
{private:
 int cima;
int V[N];
int tamano;
public:
	pila(void);
	void apilar (int x);
	int desapilar();
	bool vacio();
	bool lleno();
	void Settamano(int t);
	int Gettamano();
};

