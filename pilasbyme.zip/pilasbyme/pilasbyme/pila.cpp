#include "StdAfx.h"
#include "pila.h"


pila::pila(void)
{cima=-1;
V[N]=0;
}
void pila::apilar (int x)
{
V[++cima]=x;

}
int pila::desapilar()
{int x= V[cima--];
return x;
}
bool pila::vacio()
{if (cima==-1)
return true;
}
bool pila::lleno()
{if (cima==tamano-1)
return true;
}
int pila::Gettamano()
{  return tamano;
}
void pila::Settamano(int t)
{ tamano=t;
}