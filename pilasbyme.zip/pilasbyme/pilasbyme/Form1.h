#pragma once
#include "pila.h"

namespace pilasbyme {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	 pila A;
	 int tam=0;
	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Button^  btnapilar;
	protected: 

	private: System::Windows::Forms::Button^  btndesapilar;
	protected: 

	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::TextBox^  txtapilar;
	private: System::Windows::Forms::TextBox^  txtdesapilar;
	private: System::Windows::Forms::DataGridView^  Grid;



	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column1;
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::Button^  button1;
	private: System::Windows::Forms::TextBox^  txttamano;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->btnapilar = (gcnew System::Windows::Forms::Button());
			this->btndesapilar = (gcnew System::Windows::Forms::Button());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->txtapilar = (gcnew System::Windows::Forms::TextBox());
			this->txtdesapilar = (gcnew System::Windows::Forms::TextBox());
			this->Grid = (gcnew System::Windows::Forms::DataGridView());
			this->Column1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->txttamano = (gcnew System::Windows::Forms::TextBox());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid))->BeginInit();
			this->SuspendLayout();
			// 
			// btnapilar
			// 
			this->btnapilar->Location = System::Drawing::Point(205, 91);
			this->btnapilar->Name = L"btnapilar";
			this->btnapilar->Size = System::Drawing::Size(74, 30);
			this->btnapilar->TabIndex = 0;
			this->btnapilar->Text = L"Apilar";
			this->btnapilar->UseVisualStyleBackColor = true;
			this->btnapilar->Click += gcnew System::EventHandler(this, &Form1::btnapilar_Click);
			// 
			// btndesapilar
			// 
			this->btndesapilar->Location = System::Drawing::Point(205, 140);
			this->btndesapilar->Name = L"btndesapilar";
			this->btndesapilar->Size = System::Drawing::Size(74, 29);
			this->btndesapilar->TabIndex = 1;
			this->btndesapilar->Text = L"Desapilar";
			this->btndesapilar->UseVisualStyleBackColor = true;
			this->btndesapilar->Click += gcnew System::EventHandler(this, &Form1::btndesapilar_Click);
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(33, 100);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(42, 13);
			this->label1->TabIndex = 2;
			this->label1->Text = L"numero";
			// 
			// txtapilar
			// 
			this->txtapilar->Location = System::Drawing::Point(106, 97);
			this->txtapilar->Name = L"txtapilar";
			this->txtapilar->Size = System::Drawing::Size(72, 20);
			this->txtapilar->TabIndex = 3;
			// 
			// txtdesapilar
			// 
			this->txtdesapilar->Location = System::Drawing::Point(106, 149);
			this->txtdesapilar->Name = L"txtdesapilar";
			this->txtdesapilar->Size = System::Drawing::Size(72, 20);
			this->txtdesapilar->TabIndex = 4;
			// 
			// Grid
			// 
			this->Grid->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->Grid->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(1) {this->Column1});
			this->Grid->Location = System::Drawing::Point(75, 180);
			this->Grid->Name = L"Grid";
			this->Grid->Size = System::Drawing::Size(160, 109);
			this->Grid->TabIndex = 5;
			// 
			// Column1
			// 
			this->Column1->HeaderText = L"numero";
			this->Column1->Name = L"Column1";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(122, 21);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(30, 13);
			this->label2->TabIndex = 6;
			this->label2->Text = L"PILA";
			// 
			// button1
			// 
			this->button1->Location = System::Drawing::Point(205, 47);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(79, 28);
			this->button1->TabIndex = 7;
			this->button1->Text = L"tamano";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &Form1::button1_Click);
			// 
			// txttamano
			// 
			this->txttamano->Location = System::Drawing::Point(106, 52);
			this->txttamano->Name = L"txttamano";
			this->txttamano->Size = System::Drawing::Size(68, 20);
			this->txttamano->TabIndex = 8;
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(356, 301);
			this->Controls->Add(this->txttamano);
			this->Controls->Add(this->button1);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->Grid);
			this->Controls->Add(this->txtdesapilar);
			this->Controls->Add(this->txtapilar);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->btndesapilar);
			this->Controls->Add(this->btnapilar);
			this->Name = L"Form1";
			this->Text = L"Form1";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void btnapilar_Click(System::Object^  sender, System::EventArgs^  e) {
             int x;
			 x=Convert::ToInt32(txtapilar->Text);
		     if (A.lleno())
				 MessageBox::Show("lleno");
			 else 
			 {A.apilar(x);
			 Grid->Rows[tam]->Cells[0]->Value=x;
			 tam++;}
			 }
private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e) {
                int E = Convert::ToInt32(txttamano->Text);
				 Grid->RowCount= E;
		 }
private: System::Void btndesapilar_Click(System::Object^  sender, System::EventArgs^  e) {
			  int x;
		     if (A.vacio())
				 MessageBox::Show("vacio");
			 else 
			 {x=A.desapilar();
			  txtdesapilar->Text=Convert::ToString(x);
	
			 }

		 }
};  
}

