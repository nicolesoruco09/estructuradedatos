#pragma once

namespace ejemstringg {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Button^  btndefinir;
	protected: 
	private: System::Windows::Forms::TextBox^  txttexto;
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::Button^  button1;
	private: System::Windows::Forms::TextBox^  txtvocales;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->btndefinir = (gcnew System::Windows::Forms::Button());
			this->txttexto = (gcnew System::Windows::Forms::TextBox());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->txtvocales = (gcnew System::Windows::Forms::TextBox());
			this->SuspendLayout();
			// 
			// btndefinir
			// 
			this->btndefinir->Location = System::Drawing::Point(143, 27);
			this->btndefinir->Name = L"btndefinir";
			this->btndefinir->Size = System::Drawing::Size(73, 26);
			this->btndefinir->TabIndex = 0;
			this->btndefinir->Text = L"definir";
			this->btndefinir->UseVisualStyleBackColor = true;
			// 
			// txttexto
			// 
			this->txttexto->Location = System::Drawing::Point(64, 30);
			this->txttexto->Name = L"txttexto";
			this->txttexto->Size = System::Drawing::Size(70, 20);
			this->txttexto->TabIndex = 1;
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(12, 33);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(30, 13);
			this->label1->TabIndex = 2;
			this->label1->Text = L"texto";
			// 
			// button1
			// 
			this->button1->Location = System::Drawing::Point(15, 82);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(70, 42);
			this->button1->TabIndex = 3;
			this->button1->Text = L"nro de vocales";
			this->button1->UseVisualStyleBackColor = true;
			// 
			// txtvocales
			// 
			this->txtvocales->Location = System::Drawing::Point(102, 89);
			this->txtvocales->Name = L"txtvocales";
			this->txtvocales->Size = System::Drawing::Size(85, 20);
			this->txtvocales->TabIndex = 4;
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(284, 261);
			this->Controls->Add(this->txtvocales);
			this->Controls->Add(this->button1);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->txttexto);
			this->Controls->Add(this->btndefinir);
			this->Name = L"Form1";
			this->Text = L"Form1";
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	};
}

