#include "StdAfx.h"
#include "string.h"


string::string(void)
{ texto="N/A";
}
void string::settexto(string tex)
{texto=tex;
}
string string::gettexto()
{return texto;
}
int string::cacularvocales(int n)
{int longitud=texto.lenght();



}