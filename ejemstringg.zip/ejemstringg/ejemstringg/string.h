#pragma once
#include <iostream>
#include <string> 

using namespace std;

class string
{
private:
	string texto;
public:
	string(void);
	void settexto(string tex);
	string gettexto();
	int cacularvocales(int n);
};

