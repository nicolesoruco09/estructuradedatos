#pragma once
#define N 15
#define M 15
class matrices
{private:
  int V[N][M];
  int fila;
  int columna;
public:
	matrices(void);
	void Setfila(int f);
	int Getfila();
	void Setcolumna(int c);
	int Getcolumna();
	void insertar (int a, int x, int y);
	int abundante (int x,int y);


};

