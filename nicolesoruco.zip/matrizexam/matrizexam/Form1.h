#pragma once
#include "matrices.h"

namespace matrizexam {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	matrices A;
	int posx=0;
	int posy=0;

	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Button^  btndefinir;
	protected: 
	private: System::Windows::Forms::TextBox^  txtfila;
	private: System::Windows::Forms::TextBox^  txtcolumna;
	private: System::Windows::Forms::DataGridView^  Grid;

	private: System::Windows::Forms::TextBox^  txtingresar;
	private: System::Windows::Forms::Button^  btningresar;
	private: System::Windows::Forms::TextBox^  txtafila;
	private: System::Windows::Forms::TextBox^  txtacolumna;
	private: System::Windows::Forms::Button^  btnabundante;
	private: System::Windows::Forms::TextBox^  txtabundante;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->btndefinir = (gcnew System::Windows::Forms::Button());
			this->txtfila = (gcnew System::Windows::Forms::TextBox());
			this->txtcolumna = (gcnew System::Windows::Forms::TextBox());
			this->Grid = (gcnew System::Windows::Forms::DataGridView());
			this->txtingresar = (gcnew System::Windows::Forms::TextBox());
			this->btningresar = (gcnew System::Windows::Forms::Button());
			this->txtafila = (gcnew System::Windows::Forms::TextBox());
			this->txtacolumna = (gcnew System::Windows::Forms::TextBox());
			this->btnabundante = (gcnew System::Windows::Forms::Button());
			this->txtabundante = (gcnew System::Windows::Forms::TextBox());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid))->BeginInit();
			this->SuspendLayout();
			// 
			// btndefinir
			// 
			this->btndefinir->Location = System::Drawing::Point(176, 38);
			this->btndefinir->Name = L"btndefinir";
			this->btndefinir->Size = System::Drawing::Size(66, 31);
			this->btndefinir->TabIndex = 0;
			this->btndefinir->Text = L"definir";
			this->btndefinir->UseVisualStyleBackColor = true;
			this->btndefinir->Click += gcnew System::EventHandler(this, &Form1::btndefinir_Click);
			// 
			// txtfila
			// 
			this->txtfila->Location = System::Drawing::Point(53, 29);
			this->txtfila->Name = L"txtfila";
			this->txtfila->Size = System::Drawing::Size(100, 20);
			this->txtfila->TabIndex = 1;
			// 
			// txtcolumna
			// 
			this->txtcolumna->Location = System::Drawing::Point(51, 66);
			this->txtcolumna->Name = L"txtcolumna";
			this->txtcolumna->Size = System::Drawing::Size(102, 20);
			this->txtcolumna->TabIndex = 2;
			// 
			// Grid
			// 
			this->Grid->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->Grid->Location = System::Drawing::Point(45, 144);
			this->Grid->Name = L"Grid";
			this->Grid->Size = System::Drawing::Size(197, 116);
			this->Grid->TabIndex = 3;
			this->Grid->CellContentClick += gcnew System::Windows::Forms::DataGridViewCellEventHandler(this, &Form1::dataGridView1_CellContentClick);
			// 
			// txtingresar
			// 
			this->txtingresar->Location = System::Drawing::Point(97, 116);
			this->txtingresar->Name = L"txtingresar";
			this->txtingresar->Size = System::Drawing::Size(78, 20);
			this->txtingresar->TabIndex = 4;
			// 
			// btningresar
			// 
			this->btningresar->Location = System::Drawing::Point(208, 116);
			this->btningresar->Name = L"btningresar";
			this->btningresar->Size = System::Drawing::Size(68, 22);
			this->btningresar->TabIndex = 5;
			this->btningresar->Text = L"ingresar";
			this->btningresar->UseVisualStyleBackColor = true;
			this->btningresar->Click += gcnew System::EventHandler(this, &Form1::btningresar_Click);
			// 
			// txtafila
			// 
			this->txtafila->Location = System::Drawing::Point(324, 85);
			this->txtafila->Name = L"txtafila";
			this->txtafila->Size = System::Drawing::Size(78, 20);
			this->txtafila->TabIndex = 6;
			// 
			// txtacolumna
			// 
			this->txtacolumna->Location = System::Drawing::Point(325, 119);
			this->txtacolumna->Name = L"txtacolumna";
			this->txtacolumna->Size = System::Drawing::Size(77, 20);
			this->txtacolumna->TabIndex = 7;
			// 
			// btnabundante
			// 
			this->btnabundante->Location = System::Drawing::Point(426, 97);
			this->btnabundante->Name = L"btnabundante";
			this->btnabundante->Size = System::Drawing::Size(74, 29);
			this->btnabundante->TabIndex = 8;
			this->btnabundante->Text = L"abundante";
			this->btnabundante->UseVisualStyleBackColor = true;
			this->btnabundante->Click += gcnew System::EventHandler(this, &Form1::btnabundante_Click);
			// 
			// txtabundante
			// 
			this->txtabundante->Location = System::Drawing::Point(377, 168);
			this->txtabundante->Name = L"txtabundante";
			this->txtabundante->Size = System::Drawing::Size(100, 20);
			this->txtabundante->TabIndex = 9;
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(530, 280);
			this->Controls->Add(this->txtabundante);
			this->Controls->Add(this->btnabundante);
			this->Controls->Add(this->txtacolumna);
			this->Controls->Add(this->txtafila);
			this->Controls->Add(this->btningresar);
			this->Controls->Add(this->txtingresar);
			this->Controls->Add(this->Grid);
			this->Controls->Add(this->txtcolumna);
			this->Controls->Add(this->txtfila);
			this->Controls->Add(this->btndefinir);
			this->Name = L"Form1";
			this->Text = L"Form1";
			this->Load += gcnew System::EventHandler(this, &Form1::Form1_Load);
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void Form1_Load(System::Object^  sender, System::EventArgs^  e) {
			 }
private: System::Void btndefinir_Click(System::Object^  sender, System::EventArgs^  e) {
			 int F=Convert::ToInt32(txtfila->Text);
			 int C=Convert::ToInt32(txtcolumna->Text);
			 A.Setfila(F);
			 A.Setcolumna(C);
			 Grid->RowCount=F;
			 Grid->ColumnCount=C;
		 }
private: System::Void dataGridView1_CellContentClick(System::Object^  sender, System::Windows::Forms::DataGridViewCellEventArgs^  e) {
		 }
private: System::Void btningresar_Click(System::Object^  sender, System::EventArgs^  e) {
			 int E=Convert::ToInt32(txtingresar->Text);
			 A.insertar(E,posx,posy);
			 Grid->Rows[posx]->Cells[posy]->Value=E;
			 posy++;
			 if (posy== A.Getcolumna())
			 {posy=0;
			 posx++;}
			 if (posx==A.Getfila())
			 {MessageBox::Show("esta lleno");}

		 }
private: System::Void btnabundante_Click(System::Object^  sender, System::EventArgs^  e) {
			  int F=Convert::ToInt32(txtafila->Text);
			 int C=Convert::ToInt32(txtacolumna->Text);
			 F-1;
			 C-1;
              int E= A.abundante(F,C);
			 txtabundante->Text=Convert::ToString(E);

		 }
};
}

