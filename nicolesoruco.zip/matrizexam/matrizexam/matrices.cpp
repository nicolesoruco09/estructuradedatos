#include "StdAfx.h"
#include "matrices.h"


matrices::matrices(void)
{ V[N][M]=0;
}
void matrices::Setfila(int f)
{fila=f;
}
int matrices::Getfila()
{return fila;
}
void matrices::Setcolumna(int c)
{columna= c;
}
int matrices::Getcolumna()
{return columna;
}
void matrices::insertar (int a, int x, int y)
{V[x][y]=a;
}
int matrices::abundante (int x,int y)
{ int s=0;
 for (int i=0;i=V[x][y];i++)
	{  if (V[x][y]%i==0)
			     {s=s+i;
 }}
	return s;
}