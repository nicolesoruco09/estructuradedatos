#pragma once
#include "esfera.h"
#include "iostream"
#include "msclr\marshal_cppstd.h"
#include <string>
namespace VolumenEsfera {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace std;
	using namespace msclr;
 
	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Button^  btnCalcular;
	protected: 
	private: System::Windows::Forms::Label^  radio;
	private: System::Windows::Forms::TextBox^  txtRadio;
	private: System::Windows::Forms::TextBox^  txtVolumen;
	private: System::Windows::Forms::Label^  label2;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->btnCalcular = (gcnew System::Windows::Forms::Button());
			this->radio = (gcnew System::Windows::Forms::Label());
			this->txtRadio = (gcnew System::Windows::Forms::TextBox());
			this->txtVolumen = (gcnew System::Windows::Forms::TextBox());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->SuspendLayout();
			// 
			// btnCalcular
			// 
			this->btnCalcular->Location = System::Drawing::Point(68, 145);
			this->btnCalcular->Name = L"btnCalcular";
			this->btnCalcular->Size = System::Drawing::Size(156, 45);
			this->btnCalcular->TabIndex = 0;
			this->btnCalcular->Text = L"Calcular";
			this->btnCalcular->UseVisualStyleBackColor = true;
			this->btnCalcular->Click += gcnew System::EventHandler(this, &Form1::btnCalcular_Click);
			// 
			// radio
			// 
			this->radio->AutoSize = true;
			this->radio->Location = System::Drawing::Point(50, 39);
			this->radio->Name = L"radio";
			this->radio->Size = System::Drawing::Size(35, 13);
			this->radio->TabIndex = 1;
			this->radio->Text = L"Radio";
			// 
			// txtRadio
			// 
			this->txtRadio->Location = System::Drawing::Point(126, 32);
			this->txtRadio->Name = L"txtRadio";
			this->txtRadio->Size = System::Drawing::Size(112, 20);
			this->txtRadio->TabIndex = 2;
			// 
			// txtVolumen
			// 
			this->txtVolumen->Location = System::Drawing::Point(126, 89);
			this->txtVolumen->Name = L"txtVolumen";
			this->txtVolumen->Size = System::Drawing::Size(112, 20);
			this->txtVolumen->TabIndex = 4;
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(50, 96);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(48, 13);
			this->label2->TabIndex = 3;
			this->label2->Text = L"Volumen";
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(284, 261);
			this->Controls->Add(this->txtVolumen);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->txtRadio);
			this->Controls->Add(this->radio);
			this->Controls->Add(this->btnCalcular);
			this->Name = L"Form1";
			this->Text = L"Form1";
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void btnCalcular_Click(System::Object^  sender, System::EventArgs^  e) {
				 esfera esferita;
				 esferita.Set_radio(System::Convert::ToDouble(txtRadio->Text));
				 float volumenfin;
				 volumenfin= esferita.calcular();
				 txtVolumen->Text=System::Convert::ToString(volumenfin);

			 }
};
}

