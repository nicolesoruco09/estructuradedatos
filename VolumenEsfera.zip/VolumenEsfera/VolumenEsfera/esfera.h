#pragma once
#include "iostream"

class esfera
{
private:
	double radio;
	double volumen;
public:
	esfera(void);
	void Set_radio(float r);
	void Set_volumen(float v);
	double Get_radio ();
	double Get_volumen ();
	double calcular();

};

