#include "StdAfx.h"
#include "esfera.h"

esfera::esfera(void)
{
}
void esfera::Set_radio(float r)
{ radio = r;
}	
void esfera::Set_volumen(float v)
{ volumen = v;
}
double esfera::Get_radio ()
{ return radio;
}
double esfera::Get_volumen ()
{return volumen;
}
double esfera::calcular()
{ volumen = 3.14*4/3*radio*radio*radio;
  return volumen;
}