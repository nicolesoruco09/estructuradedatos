#pragma once
#include "colass.h"

namespace colasseliminarbyme {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	colass A;
	int pos=0;
	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Button^  btnencolar;
	protected: 
	private: System::Windows::Forms::TextBox^  txtencolar;
	private: System::Windows::Forms::Button^  btndesencolar;
	private: System::Windows::Forms::TextBox^  txtdesencolar;
	private: System::Windows::Forms::DataGridView^  Grid;

	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column1;
	private: System::Windows::Forms::TextBox^  txttamano;
	private: System::Windows::Forms::Button^  btntamano;
	private: System::Windows::Forms::Button^  button1;
	private: System::Windows::Forms::TextBox^  txteli;
	private: System::Windows::Forms::TextBox^  txteliminar;



	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->btnencolar = (gcnew System::Windows::Forms::Button());
			this->txtencolar = (gcnew System::Windows::Forms::TextBox());
			this->btndesencolar = (gcnew System::Windows::Forms::Button());
			this->txtdesencolar = (gcnew System::Windows::Forms::TextBox());
			this->Grid = (gcnew System::Windows::Forms::DataGridView());
			this->Column1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->txttamano = (gcnew System::Windows::Forms::TextBox());
			this->btntamano = (gcnew System::Windows::Forms::Button());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->txteli = (gcnew System::Windows::Forms::TextBox());
			this->txteliminar = (gcnew System::Windows::Forms::TextBox());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid))->BeginInit();
			this->SuspendLayout();
			// 
			// btnencolar
			// 
			this->btnencolar->Location = System::Drawing::Point(198, 36);
			this->btnencolar->Name = L"btnencolar";
			this->btnencolar->Size = System::Drawing::Size(75, 32);
			this->btnencolar->TabIndex = 0;
			this->btnencolar->Text = L"encolar ";
			this->btnencolar->UseVisualStyleBackColor = true;
			this->btnencolar->Click += gcnew System::EventHandler(this, &Form1::btnencolar_Click);
			// 
			// txtencolar
			// 
			this->txtencolar->Location = System::Drawing::Point(69, 43);
			this->txtencolar->Name = L"txtencolar";
			this->txtencolar->Size = System::Drawing::Size(96, 20);
			this->txtencolar->TabIndex = 1;
			// 
			// btndesencolar
			// 
			this->btndesencolar->Location = System::Drawing::Point(198, 84);
			this->btndesencolar->Name = L"btndesencolar";
			this->btndesencolar->Size = System::Drawing::Size(75, 32);
			this->btndesencolar->TabIndex = 2;
			this->btndesencolar->Text = L"desencolar";
			this->btndesencolar->UseVisualStyleBackColor = true;
			this->btndesencolar->Click += gcnew System::EventHandler(this, &Form1::btndesencolar_Click);
			// 
			// txtdesencolar
			// 
			this->txtdesencolar->Location = System::Drawing::Point(72, 91);
			this->txtdesencolar->Name = L"txtdesencolar";
			this->txtdesencolar->Size = System::Drawing::Size(93, 20);
			this->txtdesencolar->TabIndex = 3;
			// 
			// Grid
			// 
			this->Grid->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->Grid->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(1) {this->Column1});
			this->Grid->Location = System::Drawing::Point(75, 145);
			this->Grid->Name = L"Grid";
			this->Grid->Size = System::Drawing::Size(184, 117);
			this->Grid->TabIndex = 4;
			// 
			// Column1
			// 
			this->Column1->HeaderText = L"numero";
			this->Column1->Name = L"Column1";
			// 
			// txttamano
			// 
			this->txttamano->Location = System::Drawing::Point(315, 145);
			this->txttamano->Name = L"txttamano";
			this->txttamano->Size = System::Drawing::Size(79, 20);
			this->txttamano->TabIndex = 5;
			// 
			// btntamano
			// 
			this->btntamano->Location = System::Drawing::Point(315, 95);
			this->btntamano->Name = L"btntamano";
			this->btntamano->Size = System::Drawing::Size(79, 21);
			this->btntamano->TabIndex = 6;
			this->btntamano->Text = L"tamamo";
			this->btntamano->UseVisualStyleBackColor = true;
			this->btntamano->Click += gcnew System::EventHandler(this, &Form1::btntamano_Click);
			// 
			// button1
			// 
			this->button1->Location = System::Drawing::Point(283, 197);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(69, 24);
			this->button1->TabIndex = 7;
			this->button1->Text = L"eliminar";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &Form1::button1_Click);
			// 
			// txteli
			// 
			this->txteli->Location = System::Drawing::Point(369, 202);
			this->txteli->Name = L"txteli";
			this->txteli->Size = System::Drawing::Size(53, 20);
			this->txteli->TabIndex = 8;
			// 
			// txteliminar
			// 
			this->txteliminar->Location = System::Drawing::Point(315, 242);
			this->txteliminar->Name = L"txteliminar";
			this->txteliminar->Size = System::Drawing::Size(69, 20);
			this->txteliminar->TabIndex = 9;
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(435, 282);
			this->Controls->Add(this->txteliminar);
			this->Controls->Add(this->txteli);
			this->Controls->Add(this->button1);
			this->Controls->Add(this->btntamano);
			this->Controls->Add(this->txttamano);
			this->Controls->Add(this->Grid);
			this->Controls->Add(this->txtdesencolar);
			this->Controls->Add(this->btndesencolar);
			this->Controls->Add(this->txtencolar);
			this->Controls->Add(this->btnencolar);
			this->Name = L"Form1";
			this->Text = L"Form1";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void btntamano_Click(System::Object^  sender, System::EventArgs^  e) {
				 int t=Convert::ToInt32(txttamano->Text);
				 Grid->RowCount=t;
			 }
private: System::Void btnencolar_Click(System::Object^  sender, System::EventArgs^  e) {
			 int E=Convert::ToInt32(txtencolar->Text);
             A.encolar(E);
			 Grid->Rows[pos]->Cells[0]->Value=E;
			 pos++;}
		 
private: System::Void btndesencolar_Click(System::Object^  sender, System::EventArgs^  e) {
			 int E;
			 if (A.vacio())
			 {MessageBox::Show("no hay elementos");}
			 else{
			 E=A.desencolar();
			 txtdesencolar->Text=Convert::ToString(E);
			 Grid->Rows->RemoveAt(0);
			 }
		 }
private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e) {
			 int t;
		    int b;
			 t=Convert::ToInt32(txteli->Text);
			 for (int i=0;i<t;i++)
			 {
			    b= A.desencolar();
			 }
			 Grid->Rows->RemoveAt(t-1);
			 txteliminar->Text=Convert::ToString(b);
		 }  
};
}

