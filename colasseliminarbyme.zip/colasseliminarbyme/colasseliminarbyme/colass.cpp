#include "StdAfx.h"
#include "colass.h"


colass::colass(void)
{frente=0;
final=-1;
}
void colass::encolar (int e)
{V[++final]=e;
}
int colass::desencolar ()
{int x=V[frente++];
 return x;
}
bool colass::lleno()
{if (final=M-1)
     return true;
else 
	return false;
}
bool colass::vacio()
{ if (final==-1)
     return true;
else   
	return false;
}
