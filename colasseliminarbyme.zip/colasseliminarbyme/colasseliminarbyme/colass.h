#pragma once
#define M 20

 class colass
{private:
 int V[M];
 int frente;
 int final;
 int tamano;
public:
	colass(void);
	void encolar (int e);
	int desencolar ();
	bool lleno();
	bool vacio();
	
};

