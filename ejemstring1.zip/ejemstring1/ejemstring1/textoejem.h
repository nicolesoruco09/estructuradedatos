#pragma once
#include "iostream"
#include <string>

using namespace std;

 class textoejem
{
private :
	string texto;

public:
	textoejem(void);
	void settexto (string tex);
	string getexto ();
	int calcular ();

};

