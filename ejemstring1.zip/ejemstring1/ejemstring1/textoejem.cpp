#include "StdAfx.h"
#include "textoejem.h"


textoejem::textoejem(void)
{ texto="N/A";
}
void textoejem::settexto (string tex)
{ texto=tex;
}
string textoejem::getexto ()
{ return texto;
}
int textoejem::calcular ()
{int longitud=texto.length();
 int n=0;
for (int i=0;i<longitud;i++)
	{if (texto[i]=='a' || texto[i]=='e'||texto[i]=='i'||texto[i]=='o'||texto[i]=='u')
	n++;}
return n;

}