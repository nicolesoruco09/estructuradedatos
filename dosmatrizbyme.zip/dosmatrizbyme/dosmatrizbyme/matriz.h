#pragma once
#define N 15
#define M 15

class matriz
{private :
 int V[N][M];
 int fila; 
 int columna;
public:
	matriz(void);
	void Setfila (int f);
	int Getfila ();
	void Setcolumn (int c);
	int Getcolumn ();
	void insertar (int a , int x, int y);
	int suma (int x,int y);


};

