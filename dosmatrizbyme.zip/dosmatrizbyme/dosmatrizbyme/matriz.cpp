#include "StdAfx.h"
#include "matriz.h"


matriz::matriz(void)
{V[N][M]=0;
}
void matriz::Setfila (int f)
{fila=f;
}
int matriz::Getfila ()
{ return fila;
}
void matriz::Setcolumn (int c)
{columna=c;
}
int matriz::Getcolumn ()
{return columna;
}
void matriz::insertar (int a , int x, int y)
{V[x][y]=a;
}
int matriz::suma (int x,int y)
{int s=0;
  for(int i=0;i<x;i++)
  {for (int j=0;j<y;j++)
  {s=s+V[i][j];}
  }
  return s;
}
