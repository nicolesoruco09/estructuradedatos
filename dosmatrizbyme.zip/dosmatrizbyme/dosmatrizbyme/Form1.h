#pragma once
#include "matriz.h"

namespace dosmatrizbyme {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	matriz A,B,C;
	int pos1x=0,pos1y=0;
	int pos2x=0,pos2y=0;
	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::TextBox^  txtfila;
	protected: 

	protected: 
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::TextBox^  txtcolumna;

	private: System::Windows::Forms::Button^  button1;
	private: System::Windows::Forms::Button^  button2;
	private: System::Windows::Forms::TextBox^  textBox3;
	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::Label^  label4;
	private: System::Windows::Forms::TextBox^  textBox4;
	private: System::Windows::Forms::TextBox^  txtdato1;

	private: System::Windows::Forms::Label^  label5;
	private: System::Windows::Forms::TextBox^  txtdato2;

	private: System::Windows::Forms::Label^  label6;
	private: System::Windows::Forms::Button^  button3;
	private: System::Windows::Forms::Button^  button4;
	private: System::Windows::Forms::DataGridView^  Grid;
	private: System::Windows::Forms::DataGridView^  Grid2;
	private: System::Windows::Forms::TextBox^  txtsuma;
	private: System::Windows::Forms::Button^  button5;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->txtfila = (gcnew System::Windows::Forms::TextBox());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->txtcolumna = (gcnew System::Windows::Forms::TextBox());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->button2 = (gcnew System::Windows::Forms::Button());
			this->textBox3 = (gcnew System::Windows::Forms::TextBox());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->textBox4 = (gcnew System::Windows::Forms::TextBox());
			this->txtdato1 = (gcnew System::Windows::Forms::TextBox());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->txtdato2 = (gcnew System::Windows::Forms::TextBox());
			this->label6 = (gcnew System::Windows::Forms::Label());
			this->button3 = (gcnew System::Windows::Forms::Button());
			this->button4 = (gcnew System::Windows::Forms::Button());
			this->Grid = (gcnew System::Windows::Forms::DataGridView());
			this->Grid2 = (gcnew System::Windows::Forms::DataGridView());
			this->txtsuma = (gcnew System::Windows::Forms::TextBox());
			this->button5 = (gcnew System::Windows::Forms::Button());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid2))->BeginInit();
			this->SuspendLayout();
			// 
			// txtfila
			// 
			this->txtfila->Location = System::Drawing::Point(209, 25);
			this->txtfila->Name = L"txtfila";
			this->txtfila->Size = System::Drawing::Size(62, 20);
			this->txtfila->TabIndex = 0;
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(149, 28);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(20, 13);
			this->label1->TabIndex = 1;
			this->label1->Text = L"fila";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(149, 60);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(47, 13);
			this->label2->TabIndex = 2;
			this->label2->Text = L"columna";
			// 
			// txtcolumna
			// 
			this->txtcolumna->Location = System::Drawing::Point(209, 57);
			this->txtcolumna->Name = L"txtcolumna";
			this->txtcolumna->Size = System::Drawing::Size(62, 20);
			this->txtcolumna->TabIndex = 3;
			// 
			// button1
			// 
			this->button1->Location = System::Drawing::Point(154, 103);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(64, 19);
			this->button1->TabIndex = 4;
			this->button1->Text = L"ingresar";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &Form1::button1_Click);
			// 
			// button2
			// 
			this->button2->Location = System::Drawing::Point(751, 165);
			this->button2->Name = L"button2";
			this->button2->Size = System::Drawing::Size(64, 19);
			this->button2->TabIndex = 9;
			this->button2->Text = L"button2";
			this->button2->UseVisualStyleBackColor = true;
			// 
			// textBox3
			// 
			this->textBox3->Location = System::Drawing::Point(662, 179);
			this->textBox3->Name = L"textBox3";
			this->textBox3->Size = System::Drawing::Size(62, 20);
			this->textBox3->TabIndex = 8;
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(602, 182);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(35, 13);
			this->label3->TabIndex = 7;
			this->label3->Text = L"label3";
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Location = System::Drawing::Point(602, 150);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(35, 13);
			this->label4->TabIndex = 6;
			this->label4->Text = L"label4";
			// 
			// textBox4
			// 
			this->textBox4->Location = System::Drawing::Point(662, 147);
			this->textBox4->Name = L"textBox4";
			this->textBox4->Size = System::Drawing::Size(62, 20);
			this->textBox4->TabIndex = 5;
			// 
			// txtdato1
			// 
			this->txtdato1->Location = System::Drawing::Point(72, 106);
			this->txtdato1->Name = L"txtdato1";
			this->txtdato1->Size = System::Drawing::Size(62, 20);
			this->txtdato1->TabIndex = 11;
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Location = System::Drawing::Point(12, 109);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(28, 13);
			this->label5->TabIndex = 10;
			this->label5->Text = L"dato";
			// 
			// txtdato2
			// 
			this->txtdato2->Location = System::Drawing::Point(348, 102);
			this->txtdato2->Name = L"txtdato2";
			this->txtdato2->Size = System::Drawing::Size(62, 20);
			this->txtdato2->TabIndex = 13;
			// 
			// label6
			// 
			this->label6->AutoSize = true;
			this->label6->Location = System::Drawing::Point(288, 105);
			this->label6->Name = L"label6";
			this->label6->Size = System::Drawing::Size(28, 13);
			this->label6->TabIndex = 12;
			this->label6->Text = L"dato";
			// 
			// button3
			// 
			this->button3->Location = System::Drawing::Point(291, 39);
			this->button3->Name = L"button3";
			this->button3->Size = System::Drawing::Size(64, 19);
			this->button3->TabIndex = 14;
			this->button3->Text = L"definir";
			this->button3->UseVisualStyleBackColor = true;
			this->button3->Click += gcnew System::EventHandler(this, &Form1::button3_Click);
			// 
			// button4
			// 
			this->button4->Location = System::Drawing::Point(437, 102);
			this->button4->Name = L"button4";
			this->button4->Size = System::Drawing::Size(64, 19);
			this->button4->TabIndex = 15;
			this->button4->Text = L"ingresar";
			this->button4->UseVisualStyleBackColor = true;
			this->button4->Click += gcnew System::EventHandler(this, &Form1::button4_Click);
			// 
			// Grid
			// 
			this->Grid->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->Grid->Location = System::Drawing::Point(35, 155);
			this->Grid->Name = L"Grid";
			this->Grid->Size = System::Drawing::Size(165, 103);
			this->Grid->TabIndex = 16;
			// 
			// Grid2
			// 
			this->Grid2->AllowUserToAddRows = false;
			this->Grid2->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->Grid2->Location = System::Drawing::Point(317, 155);
			this->Grid2->Name = L"Grid2";
			this->Grid2->Size = System::Drawing::Size(184, 99);
			this->Grid2->TabIndex = 17;
			// 
			// txtsuma
			// 
			this->txtsuma->Location = System::Drawing::Point(224, 177);
			this->txtsuma->Name = L"txtsuma";
			this->txtsuma->Size = System::Drawing::Size(81, 20);
			this->txtsuma->TabIndex = 18;
			// 
			// button5
			// 
			this->button5->Location = System::Drawing::Point(224, 128);
			this->button5->Name = L"button5";
			this->button5->Size = System::Drawing::Size(66, 30);
			this->button5->TabIndex = 19;
			this->button5->Text = L"SUMA";
			this->button5->UseVisualStyleBackColor = true;
			this->button5->Click += gcnew System::EventHandler(this, &Form1::button5_Click);
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(542, 292);
			this->Controls->Add(this->button5);
			this->Controls->Add(this->txtsuma);
			this->Controls->Add(this->Grid2);
			this->Controls->Add(this->Grid);
			this->Controls->Add(this->button4);
			this->Controls->Add(this->button3);
			this->Controls->Add(this->txtdato2);
			this->Controls->Add(this->label6);
			this->Controls->Add(this->txtdato1);
			this->Controls->Add(this->label5);
			this->Controls->Add(this->button2);
			this->Controls->Add(this->textBox3);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->textBox4);
			this->Controls->Add(this->button1);
			this->Controls->Add(this->txtcolumna);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->txtfila);
			this->Name = L"Form1";
			this->Text = L"Form1";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid2))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void button3_Click(System::Object^  sender, System::EventArgs^  e) {
				 int F=Convert::ToInt32(txtfila->Text);
				 int C=Convert::ToInt32(txtcolumna->Text);
				 A.Setfila(F);
				 A.Setcolumn(C);
				 B.Setfila(F);
				 B.Setcolumn(C);
				 Grid->RowCount=F;
				 Grid->ColumnCount=C;
				 Grid2->RowCount=F;
				 Grid2->ColumnCount=C;

			 }
private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e) {
			 int E=Convert::ToInt32(txtdato1->Text);
			 A.insertar(E,pos1x,pos1y);
			 Grid->Rows[pos1x]->Cells[pos1y]->Value=E;
			 pos1y++;
			 if (pos1y== A.Getcolumn())
			 {pos1y=0;
			 pos1x++;}
			  if (pos1x== A.Getfila())
			 {MessageBox::Show("esta lleno");}
		 }
private: System::Void button4_Click(System::Object^  sender, System::EventArgs^  e) {
			 int E=Convert::ToInt32(txtdato2->Text);
			 B.insertar(E,pos2x,pos2y);
			 Grid2->Rows[pos2x]->Cells[pos2y]->Value=E;
			 pos2y++;
			 if (pos2y== B.Getcolumn())
			 {pos2y=0;
			 pos2x++;}
			  if (pos2x== B.Getfila()+1)
			 {MessageBox::Show("esta lleno");}
		 }
private: System::Void button5_Click(System::Object^  sender, System::EventArgs^  e) {
			
			 int S=B.suma(B.Getfila(),B.Getcolumn())+A.suma(A.Getfila(),A.Getcolumn());
			txtsuma->Text=Convert::ToString(S);
		 }
};
}

