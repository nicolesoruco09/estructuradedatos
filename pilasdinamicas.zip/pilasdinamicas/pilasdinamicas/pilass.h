#pragma once
#define M 20
class pilass
{private:
   int numero[M];
   pilass *puntero;
public:
	pilass(void);
	void enpilar (pilass *&cima);
	void Desapilar(pilass *&cima);
    
};

