#include "StdAfx.h"
#include "pilass.h"


pilass::pilass(void)
{ puntero = NULL;
numero[M]=0;
}
void pilass::enpilar (pilass *&cima)
{ pilass *Elemento = new pilass;
   if(cima == NULL){ 
	   cima = Elemento;}
   else{ cima->puntero = Elemento; 
   cima = Elemento;}
}
void pilass::Desapilar(pilass *&cima)
{
}