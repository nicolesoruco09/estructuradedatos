#include "StdAfx.h"
#include "multiplo7.h"


multiplo7::multiplo7(void)
{vector[N]=0;
tamano=0;
}
void multiplo7::Set_tamano(int tam)
{tamano=tam;
}
int multiplo7::Get_tamano()
{return tamano;
}
void multiplo7::Set_vector(int e,int pos)
{vector[pos]=e;
}
int multiplo7::Get_vector(int pos)
{return vector[pos];
}
void multiplo7::calcular (int tam)
{int aux=4;
 vector[0]=1;
 for (int i=1;i<tam;i++)
 { vector[i]=aux;
  aux=aux+4;
 }
}