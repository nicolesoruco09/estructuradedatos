#pragma once
#include "iostream"
#define N 100
 class multiplo7
{
private:
	int vector[N],tamano;
public:
	multiplo7(void);
	void Set_tamano(int tam);
	int Get_tamano();
	void Set_vector(int e,int pos);
	int Get_vector(int pos);
	void calcular (int tam);
};

