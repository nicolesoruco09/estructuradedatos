#pragma once
#include "pilas.h"
#include "msclr\marshal_cppstd.h"
namespace pilasnodobyme {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace msclr::interop;
	pilas A;
	nodo aux;
	int pos=0;

	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Button^  btnapilar;
	private: System::Windows::Forms::Button^  btndesapilar;
	protected: 


	private: System::Windows::Forms::TextBox^  txtnombre;
	private: System::Windows::Forms::TextBox^  txtnombre1;
	protected: 

	protected: 



	private: System::Windows::Forms::TextBox^  txtcarnet;
	private: System::Windows::Forms::DataGridView^  Grid;



	private: System::Windows::Forms::TextBox^  txtcarnet1;
	private: System::Windows::Forms::TextBox^  txttamano;
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::Button^  button1;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column1;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column2;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->btnapilar = (gcnew System::Windows::Forms::Button());
			this->btndesapilar = (gcnew System::Windows::Forms::Button());
			this->txtnombre = (gcnew System::Windows::Forms::TextBox());
			this->txtnombre1 = (gcnew System::Windows::Forms::TextBox());
			this->txtcarnet = (gcnew System::Windows::Forms::TextBox());
			this->Grid = (gcnew System::Windows::Forms::DataGridView());
			this->txtcarnet1 = (gcnew System::Windows::Forms::TextBox());
			this->txttamano = (gcnew System::Windows::Forms::TextBox());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->Column1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Column2 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid))->BeginInit();
			this->SuspendLayout();
			// 
			// btnapilar
			// 
			this->btnapilar->Location = System::Drawing::Point(188, 38);
			this->btnapilar->Name = L"btnapilar";
			this->btnapilar->Size = System::Drawing::Size(75, 36);
			this->btnapilar->TabIndex = 0;
			this->btnapilar->Text = L"apilar";
			this->btnapilar->UseVisualStyleBackColor = true;
			this->btnapilar->Click += gcnew System::EventHandler(this, &Form1::btnapilar_Click);
			// 
			// btndesapilar
			// 
			this->btndesapilar->Location = System::Drawing::Point(188, 113);
			this->btndesapilar->Name = L"btndesapilar";
			this->btndesapilar->Size = System::Drawing::Size(75, 33);
			this->btndesapilar->TabIndex = 1;
			this->btndesapilar->Text = L"desapilar";
			this->btndesapilar->UseVisualStyleBackColor = true;
			this->btndesapilar->Click += gcnew System::EventHandler(this, &Form1::btndesapilar_Click);
			// 
			// txtnombre
			// 
			this->txtnombre->Location = System::Drawing::Point(67, 38);
			this->txtnombre->Name = L"txtnombre";
			this->txtnombre->Size = System::Drawing::Size(84, 20);
			this->txtnombre->TabIndex = 2;
			// 
			// txtnombre1
			// 
			this->txtnombre1->Location = System::Drawing::Point(67, 113);
			this->txtnombre1->Name = L"txtnombre1";
			this->txtnombre1->Size = System::Drawing::Size(84, 20);
			this->txtnombre1->TabIndex = 3;
			// 
			// txtcarnet
			// 
			this->txtcarnet->Location = System::Drawing::Point(67, 64);
			this->txtcarnet->Name = L"txtcarnet";
			this->txtcarnet->Size = System::Drawing::Size(84, 20);
			this->txtcarnet->TabIndex = 4;
			// 
			// Grid
			// 
			this->Grid->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->Grid->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(2) {this->Column1, this->Column2});
			this->Grid->Location = System::Drawing::Point(118, 171);
			this->Grid->Name = L"Grid";
			this->Grid->Size = System::Drawing::Size(274, 152);
			this->Grid->TabIndex = 5;
			this->Grid->CellContentClick += gcnew System::Windows::Forms::DataGridViewCellEventHandler(this, &Form1::dataGridView1_CellContentClick);
			// 
			// txtcarnet1
			// 
			this->txtcarnet1->Location = System::Drawing::Point(69, 145);
			this->txtcarnet1->Name = L"txtcarnet1";
			this->txtcarnet1->Size = System::Drawing::Size(81, 20);
			this->txtcarnet1->TabIndex = 6;
			// 
			// txttamano
			// 
			this->txttamano->Location = System::Drawing::Point(326, 38);
			this->txttamano->Name = L"txttamano";
			this->txttamano->Size = System::Drawing::Size(66, 20);
			this->txttamano->TabIndex = 7;
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(348, 61);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(35, 13);
			this->label1->TabIndex = 8;
			this->label1->Text = L"label1";
			// 
			// button1
			// 
			this->button1->Location = System::Drawing::Point(420, 37);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(90, 21);
			this->button1->TabIndex = 9;
			this->button1->Text = L"tamano";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &Form1::button1_Click);
			// 
			// Column1
			// 
			this->Column1->HeaderText = L"nombre";
			this->Column1->Name = L"Column1";
			// 
			// Column2
			// 
			this->Column2->HeaderText = L"carnet";
			this->Column2->Name = L"Column2";
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(544, 346);
			this->Controls->Add(this->button1);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->txttamano);
			this->Controls->Add(this->txtcarnet1);
			this->Controls->Add(this->Grid);
			this->Controls->Add(this->txtcarnet);
			this->Controls->Add(this->txtnombre1);
			this->Controls->Add(this->txtnombre);
			this->Controls->Add(this->btndesapilar);
			this->Controls->Add(this->btnapilar);
			this->Name = L"Form1";
			this->Text = L"Form1";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void dataGridView1_CellContentClick(System::Object^  sender, System::Windows::Forms::DataGridViewCellEventArgs^  e) {


			 }
private: System::Void btnapilar_Click(System::Object^  sender, System::EventArgs^  e) {
			 string nom;
			 int car;
             nom=marshal_as<std::string>(Convert::ToString(txtnombre->Text));
			 car=Convert::ToInt32(txtcarnet->Text);
			 aux.SetN(nom);
			 aux.SetC(car);
			 if (A.lleno())
			 {MessageBox::Show("esta lleno");}
			 else {
			 A.apilar(aux);
			 Grid->Rows[pos]->Cells[0]->Value=marshal_as<String^>(nom);
			 Grid->Rows[pos]->Cells[1]->Value=car;
			 pos++;
			 }}
private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e) {
			  int E = Convert::ToInt32(txttamano->Text);
				 Grid->RowCount= E;
		 }
private: System::Void btndesapilar_Click(System::Object^  sender, System::EventArgs^  e) {
			 string nom;
			 int car;
			 if(A.vacio())
			 {MessageBox::Show("no hay elementos");}
			 else {
				 aux= A.desapilar();
				 nom= aux.GetN();
				 car= aux.GetC();
				 txtnombre1->Text=marshal_as<String^>(nom);
				 txtcarnet1->Text=Convert::ToString(car);
				 Grid->Rows[pos-1]->Cells[0]->Value=0;
				 Grid->Rows[pos-1]->Cells[1]->Value=0;
				 pos--;
			 }
		 }
};
}

