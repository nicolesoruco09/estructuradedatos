#include "StdAfx.h"
#include "nodo.h"

nodo::nodo(void)
{
}
void nodo::SetN (string n){
nombre=n;
}
string nodo::GetN  (){
return nombre; }
void nodo::SetC (int c){
carnet=c;}
int nodo::GetC (){
return carnet;}