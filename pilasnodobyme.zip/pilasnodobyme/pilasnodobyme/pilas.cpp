#include "StdAfx.h"
#include "pilas.h"


pilas::pilas(void)
{ top=-1;
}
void pilas::apilar (nodo x)
{V[++top]=x;
}
nodo pilas::desapilar ()
{nodo X=V[top--];
 return X;
}
bool pilas::lleno()
{if (top==M-1)
   return true;
else 
	 return false;
}
bool pilas::vacio()
{if (top==-1)
   return true;
else 
	 return false;
}