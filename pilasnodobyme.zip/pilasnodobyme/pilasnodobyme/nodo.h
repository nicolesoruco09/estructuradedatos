#pragma once
#include <string>

using namespace std;
 class nodo
{protected:
 string nombre;
 int carnet;
public:
	nodo(void);
	void SetN (string n);
	string GetN  ();
	void SetC (int c);
	int GetC ();
};

