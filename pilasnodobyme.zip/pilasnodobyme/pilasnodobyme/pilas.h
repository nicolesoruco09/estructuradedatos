#pragma once
#include "nodo.h"
#define M 25

class pilas: public nodo{
private:
	int top;
	nodo V[M];
public:
	pilas(void);
	void apilar (nodo x);
	nodo desapilar ();
	bool lleno();
	bool vacio();

};

