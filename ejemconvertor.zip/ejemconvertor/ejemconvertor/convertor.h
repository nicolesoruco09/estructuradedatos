#pragma once
#include "iostream"

using namespace std;

 class convertor
{
private:
	double kilometro;
	double metro;
	double centimetro;
public:
	convertor(void);
	void Set_kilometro(double k);
	void Set_metro(double m);
	void Set_centimetro(double c);
	double Get_kilometro();
	double Get_metro();
	double Get_centimetro();
	void convertir(double x);
};

