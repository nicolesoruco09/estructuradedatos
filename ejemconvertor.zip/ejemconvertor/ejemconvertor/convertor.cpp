#include "StdAfx.h"
#include "convertor.h"


convertor::convertor(void)
{}
void convertor::Set_kilometro(double k)
{ kilometro=k;
}
void convertor::Set_metro(double m)
{ metro=m;
}
void convertor::Set_centimetro(double c)
{ centimetro=c;
}
double convertor::Get_kilometro()
{  return kilometro;
}
double convertor::Get_metro()
{  return metro;
}
double convertor::Get_centimetro()
{  return centimetro;
}
void convertor::convertir(double x)
{ 
	metro=x*1000;
	centimetro=x*100000;
}





