#pragma once
 class Nodo
{protected:
 int numero;
 double carnet;
public:
	Nodo(void);
	void insertar (int x , double y);
	int GetN();
	double GetC();
};

