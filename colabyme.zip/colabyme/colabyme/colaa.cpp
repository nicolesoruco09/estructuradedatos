#include "StdAfx.h"
#include "colaa.h"


colaa::colaa(void)
{frente=0;
 final=-1;
}
void colaa::encolar (Nodo x)
{V[++final]=x;
}
Nodo colaa::desencolar ()
{Nodo aux =V[frente++];
  return aux;
}
bool colaa::lleno()
{if (final==N-1)
   return true;
else 
	return false;
}
bool colaa::vacio ()
{if (final==-1)
  return true;
else 
	return false;
}