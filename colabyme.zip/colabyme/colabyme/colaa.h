#pragma once
#include "Nodo.h"
#define N 25
 class colaa: public Nodo{
private : 
	int frente;
	int final;
	Nodo V[N];
public:
	colaa(void);
	void encolar (Nodo x);
	Nodo desencolar ();
	bool lleno();
	bool vacio ();
};

