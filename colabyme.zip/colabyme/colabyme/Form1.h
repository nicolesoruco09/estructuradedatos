#pragma once
#include "colaa.h"

namespace colabyme {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
colaa A;
int pos;
Nodo B;
	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Button^  btntamano;
	protected: 
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::TextBox^  txttamano;
	private: System::Windows::Forms::TextBox^  txtcarnet;
	private: System::Windows::Forms::TextBox^  txtnum;
	private: System::Windows::Forms::Button^  btnencolar;
	private: System::Windows::Forms::TextBox^  txtcarnett;
	private: System::Windows::Forms::TextBox^  txtnumm;
	private: System::Windows::Forms::Button^  btndesencolar;
	private: System::Windows::Forms::DataGridView^  Grid;

	private: System::Windows::Forms::DataGridViewTextBoxColumn^  numero;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column1;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->btntamano = (gcnew System::Windows::Forms::Button());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->txttamano = (gcnew System::Windows::Forms::TextBox());
			this->txtcarnet = (gcnew System::Windows::Forms::TextBox());
			this->txtnum = (gcnew System::Windows::Forms::TextBox());
			this->btnencolar = (gcnew System::Windows::Forms::Button());
			this->txtcarnett = (gcnew System::Windows::Forms::TextBox());
			this->txtnumm = (gcnew System::Windows::Forms::TextBox());
			this->btndesencolar = (gcnew System::Windows::Forms::Button());
			this->Grid = (gcnew System::Windows::Forms::DataGridView());
			this->numero = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Column1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid))->BeginInit();
			this->SuspendLayout();
			// 
			// btntamano
			// 
			this->btntamano->Location = System::Drawing::Point(177, 17);
			this->btntamano->Name = L"btntamano";
			this->btntamano->Size = System::Drawing::Size(64, 29);
			this->btntamano->TabIndex = 0;
			this->btntamano->Text = L"definir";
			this->btntamano->UseVisualStyleBackColor = true;
			this->btntamano->Click += gcnew System::EventHandler(this, &Form1::btntamano_Click);
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(13, 25);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(42, 13);
			this->label1->TabIndex = 1;
			this->label1->Text = L"tamano";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(25, 76);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(45, 13);
			this->label2->TabIndex = 2;
			this->label2->Text = L"encolar ";
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(13, 163);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(62, 13);
			this->label3->TabIndex = 3;
			this->label3->Text = L"desencolar ";
			// 
			// txttamano
			// 
			this->txttamano->Location = System::Drawing::Point(76, 22);
			this->txttamano->Name = L"txttamano";
			this->txttamano->Size = System::Drawing::Size(69, 20);
			this->txttamano->TabIndex = 4;
			// 
			// txtcarnet
			// 
			this->txtcarnet->Location = System::Drawing::Point(76, 119);
			this->txtcarnet->Name = L"txtcarnet";
			this->txtcarnet->Size = System::Drawing::Size(74, 20);
			this->txtcarnet->TabIndex = 5;
			// 
			// txtnum
			// 
			this->txtnum->Location = System::Drawing::Point(77, 91);
			this->txtnum->Name = L"txtnum";
			this->txtnum->Size = System::Drawing::Size(74, 20);
			this->txtnum->TabIndex = 6;
			// 
			// btnencolar
			// 
			this->btnencolar->Location = System::Drawing::Point(177, 91);
			this->btnencolar->Name = L"btnencolar";
			this->btnencolar->Size = System::Drawing::Size(64, 25);
			this->btnencolar->TabIndex = 7;
			this->btnencolar->Text = L"ingresar";
			this->btnencolar->UseVisualStyleBackColor = true;
			this->btnencolar->Click += gcnew System::EventHandler(this, &Form1::btnencolar_Click);
			// 
			// txtcarnett
			// 
			this->txtcarnett->Location = System::Drawing::Point(77, 221);
			this->txtcarnett->Name = L"txtcarnett";
			this->txtcarnett->Size = System::Drawing::Size(73, 20);
			this->txtcarnett->TabIndex = 8;
			// 
			// txtnumm
			// 
			this->txtnumm->Location = System::Drawing::Point(76, 182);
			this->txtnumm->Name = L"txtnumm";
			this->txtnumm->Size = System::Drawing::Size(74, 20);
			this->txtnumm->TabIndex = 9;
			// 
			// btndesencolar
			// 
			this->btndesencolar->Location = System::Drawing::Point(178, 178);
			this->btndesencolar->Name = L"btndesencolar";
			this->btndesencolar->Size = System::Drawing::Size(62, 26);
			this->btndesencolar->TabIndex = 10;
			this->btndesencolar->Text = L"eliminar";
			this->btndesencolar->UseVisualStyleBackColor = true;
			this->btndesencolar->Click += gcnew System::EventHandler(this, &Form1::btndesencolar_Click);
			// 
			// Grid
			// 
			this->Grid->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->Grid->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(2) {this->numero, this->Column1});
			this->Grid->Location = System::Drawing::Point(261, 25);
			this->Grid->Name = L"Grid";
			this->Grid->Size = System::Drawing::Size(259, 151);
			this->Grid->TabIndex = 11;
			// 
			// numero
			// 
			this->numero->HeaderText = L"numero";
			this->numero->Name = L"numero";
			// 
			// Column1
			// 
			this->Column1->HeaderText = L"carnet";
			this->Column1->Name = L"Column1";
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(576, 269);
			this->Controls->Add(this->Grid);
			this->Controls->Add(this->btndesencolar);
			this->Controls->Add(this->txtnumm);
			this->Controls->Add(this->txtcarnett);
			this->Controls->Add(this->btnencolar);
			this->Controls->Add(this->txtnum);
			this->Controls->Add(this->txtcarnet);
			this->Controls->Add(this->txttamano);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->btntamano);
			this->Name = L"Form1";
			this->Text = L"Form1";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void btntamano_Click(System::Object^  sender, System::EventArgs^  e) {
				 int E =Convert::ToInt32(txttamano->Text);
				 if (E>0)
					 Grid->RowCount=E;
				 else 
					 MessageBox::Show("nop");
			 }
private: System::Void btnencolar_Click(System::Object^  sender, System::EventArgs^  e) {
			 double car; int nume;
			 nume=Convert::ToInt32(txtnum->Text);
			 car=Convert::ToDouble(txtcarnet->Text);
			 B.insertar(nume,car);
				 A.encolar(B);
				 Grid->Rows[pos]->Cells[0]->Value= nume;
				 Grid->Rows[pos]->Cells[1]->Value= car;
				 pos++;
		 }
private: System::Void btndesencolar_Click(System::Object^  sender, System::EventArgs^  e) {
		 if (A.vacio())
			 MessageBox::Show("a");
		 else 
			 B=A.desencolar();
	        txtnumm->Text=Convert::ToString( B.GetN());
            txtcarnett->Text=Convert::ToString( B.GetC());
			Grid->Rows->RemoveAt(0);
		 }
};
}

