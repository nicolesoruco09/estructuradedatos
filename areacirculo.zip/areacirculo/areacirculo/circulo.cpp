#include "StdAfx.h"
#include "circulo.h"


circulo::circulo(void)
{
}
