#pragma once
#include "iostream"

 class circulo

{
private:
	int 
public:
	circulo(void);
};

