#pragma once
#include "Imparess.h"
#include "iostream"

namespace impares {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace std;

	Imparess A;
	int tam;
	int pos=0;
	

	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::DataGridView^  Grid;
	protected: 
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  impar;
	private: System::Windows::Forms::Button^  btnAsignar;
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::TextBox^  txtAsignar;
	private: System::Windows::Forms::Button^  btnCalcular;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->Grid = (gcnew System::Windows::Forms::DataGridView());
			this->impar = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->btnAsignar = (gcnew System::Windows::Forms::Button());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->txtAsignar = (gcnew System::Windows::Forms::TextBox());
			this->btnCalcular = (gcnew System::Windows::Forms::Button());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid))->BeginInit();
			this->SuspendLayout();
			// 
			// Grid
			// 
			this->Grid->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->Grid->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(1) {this->impar});
			this->Grid->Location = System::Drawing::Point(25, 115);
			this->Grid->Name = L"Grid";
			this->Grid->Size = System::Drawing::Size(187, 118);
			this->Grid->TabIndex = 0;
			// 
			// impar
			// 
			this->impar->HeaderText = L"imparess";
			this->impar->Name = L"impar";
			// 
			// btnAsignar
			// 
			this->btnAsignar->Location = System::Drawing::Point(155, 23);
			this->btnAsignar->Name = L"btnAsignar";
			this->btnAsignar->Size = System::Drawing::Size(69, 22);
			this->btnAsignar->TabIndex = 1;
			this->btnAsignar->Text = L"asignar";
			this->btnAsignar->UseVisualStyleBackColor = true;
			this->btnAsignar->Click += gcnew System::EventHandler(this, &Form1::btnAsignar_Click);
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(22, 28);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(42, 13);
			this->label1->TabIndex = 2;
			this->label1->Text = L"tamano";
			// 
			// txtAsignar
			// 
			this->txtAsignar->Location = System::Drawing::Point(70, 23);
			this->txtAsignar->Name = L"txtAsignar";
			this->txtAsignar->Size = System::Drawing::Size(68, 20);
			this->txtAsignar->TabIndex = 3;
			// 
			// btnCalcular
			// 
			this->btnCalcular->Location = System::Drawing::Point(109, 71);
			this->btnCalcular->Name = L"btnCalcular";
			this->btnCalcular->Size = System::Drawing::Size(69, 22);
			this->btnCalcular->TabIndex = 4;
			this->btnCalcular->Text = L"calcular";
			this->btnCalcular->UseVisualStyleBackColor = true;
			this->btnCalcular->Click += gcnew System::EventHandler(this, &Form1::btnCalcular_Click);
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(284, 261);
			this->Controls->Add(this->btnCalcular);
			this->Controls->Add(this->txtAsignar);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->btnAsignar);
			this->Controls->Add(this->Grid);
			this->Name = L"Form1";
			this->Text = L"Form1";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void btnCalcular_Click(System::Object^  sender, System::EventArgs^  e) {
				 int nume=-1;
				 for (int i=0;i<tam;i++)
				 {nume= A.calcular(nume);
				 Grid->Rows[pos]->Cells[0]->Value=nume;
				 pos++;
				 }
			 }
private: System::Void btnAsignar_Click(System::Object^  sender, System::EventArgs^  e) {
			tam= Convert::ToInt32(txtAsignar->Text);
			A.Set_tamano(tam);
			Grid->RowCount=tam;
		 }
};
}

