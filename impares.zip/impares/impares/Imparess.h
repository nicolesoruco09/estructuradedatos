#pragma once
#include "iostream"
#define N 30

 class Imparess

{private:
  int tamano ;
  int numero [N];
public:
	Imparess(void);
	void Set_tamano(int tam);
	int Get_tamano();
    void Set_vector(int elem, int pos);
	int Get_vector(int pos);
	int calcular (int num);

};

