#include "StdAfx.h"
#include "Imparess.h"


Imparess::Imparess(void)
{numero[N]=0;
 tamano =0;
}
void Imparess::Set_tamano(int tam)
{tamano=tam;
}
int Imparess::Get_tamano()
{return tamano;
}
void Imparess::Set_vector(int elem, int pos)
{numero[pos]=elem;
}
int Imparess::Get_vector(int pos)
{return numero [pos];
}
int Imparess::calcular (int num)
{ num=num+2;
return num;
}