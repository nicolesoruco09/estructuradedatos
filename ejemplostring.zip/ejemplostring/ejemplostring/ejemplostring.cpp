// ejemplostring.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "conio.h"
#include  <iostream>
#include  <string>
using namespace std;

void main()
{ int longitud, cont=0 , pos;
  char aux;

  string var1,var2,nombre;

  cout<<endl<<"ingrese un nombre:";
  getline (cin,nombre);
  cout<<"el nombre es :"<<nombre<<endl;


  longitud=nombre.length();
   cout<<"la longitud del string es:"<<longitud<<endl;


   cout<<"�ngrese el segundo string";
    getline (cin,var2);
	if (nombre.compare(var2)==0)
		cout<<"son iguales"<<endl;
	else 
		cout<<"no son iguales"<<endl;


	for (int i=0;i<longitud;i++)
	if (nombre[i]=='a' || nombre[i]=='e'||nombre[i]=='i'||nombre[i]=='o'||nombre[i]=='u')
			cont++;
	cout<<"Numero de vocales: "<<cont<<endl;



  getch();


}

