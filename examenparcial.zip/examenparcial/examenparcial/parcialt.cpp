#include "StdAfx.h"
#include "parcialt.h"


parcialt::parcialt(void)
{ numero[K]=0;
 tamano =0;
}
void parcialt::Settamano(int tam)
{ tamano=tam;
}
int parcialt::Gettamano ()
{ return tamano;
}
void parcialt::Setnumero (int elem, int pos)
{ numero[pos]=elem;
}
int parcialt::Getnumero (int pos )
{ return numero[pos];
}
string parcialt::calcularpar (int tam)
{ string a,b;int aux=0;
 a="par";
 b="no par";
 for (int i=0;i<tam;i++)
{	 if (numero[i]%2!=0)
		aux++;	 
 }
 if (aux==0)
     return a;
 else

 return b;
}
