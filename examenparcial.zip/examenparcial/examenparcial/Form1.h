#pragma once
#include "parcialt.h"
#include "msclr\marshal_cppstd.h"

namespace examenparcial {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace msclr::interop;

	parcialt C;
	int pos=0;

	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Button^  btndesignar;
	private: System::Windows::Forms::TextBox^  txttamano;
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::TextBox^  txtnumero;
	private: System::Windows::Forms::Button^  btnintroducir;
	private: System::Windows::Forms::DataGridView^  Grid;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  numero;
	private: System::Windows::Forms::Button^  button1;
	private: System::Windows::Forms::TextBox^  txtpares;
	protected: 

	protected: 

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->btndesignar = (gcnew System::Windows::Forms::Button());
			this->txttamano = (gcnew System::Windows::Forms::TextBox());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->txtnumero = (gcnew System::Windows::Forms::TextBox());
			this->btnintroducir = (gcnew System::Windows::Forms::Button());
			this->Grid = (gcnew System::Windows::Forms::DataGridView());
			this->numero = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->txtpares = (gcnew System::Windows::Forms::TextBox());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid))->BeginInit();
			this->SuspendLayout();
			// 
			// btndesignar
			// 
			this->btndesignar->Location = System::Drawing::Point(180, 39);
			this->btndesignar->Name = L"btndesignar";
			this->btndesignar->Size = System::Drawing::Size(64, 26);
			this->btndesignar->TabIndex = 0;
			this->btndesignar->Text = L"designar";
			this->btndesignar->UseVisualStyleBackColor = true;
			this->btndesignar->Click += gcnew System::EventHandler(this, &Form1::btndesignar_Click);
			// 
			// txttamano
			// 
			this->txttamano->Location = System::Drawing::Point(69, 39);
			this->txttamano->Name = L"txttamano";
			this->txttamano->Size = System::Drawing::Size(96, 20);
			this->txttamano->TabIndex = 1;
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(12, 42);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(42, 13);
			this->label1->TabIndex = 2;
			this->label1->Text = L"tamano";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(12, 81);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(42, 13);
			this->label2->TabIndex = 4;
			this->label2->Text = L"numero";
			// 
			// txtnumero
			// 
			this->txtnumero->Location = System::Drawing::Point(69, 78);
			this->txtnumero->Name = L"txtnumero";
			this->txtnumero->Size = System::Drawing::Size(96, 20);
			this->txtnumero->TabIndex = 3;
			// 
			// btnintroducir
			// 
			this->btnintroducir->Location = System::Drawing::Point(180, 77);
			this->btnintroducir->Name = L"btnintroducir";
			this->btnintroducir->Size = System::Drawing::Size(67, 20);
			this->btnintroducir->TabIndex = 5;
			this->btnintroducir->Text = L"introducir";
			this->btnintroducir->UseVisualStyleBackColor = true;
			this->btnintroducir->Click += gcnew System::EventHandler(this, &Form1::btnintroducir_Click);
			// 
			// Grid
			// 
			this->Grid->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->Grid->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(1) {this->numero});
			this->Grid->Location = System::Drawing::Point(25, 120);
			this->Grid->Name = L"Grid";
			this->Grid->Size = System::Drawing::Size(155, 113);
			this->Grid->TabIndex = 6;
			// 
			// numero
			// 
			this->numero->HeaderText = L"Column1";
			this->numero->Name = L"numero";
			// 
			// button1
			// 
			this->button1->Location = System::Drawing::Point(198, 110);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(65, 33);
			this->button1->TabIndex = 7;
			this->button1->Text = L"calcular";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &Form1::button1_Click);
			// 
			// txtpares
			// 
			this->txtpares->Location = System::Drawing::Point(198, 149);
			this->txtpares->Name = L"txtpares";
			this->txtpares->Size = System::Drawing::Size(68, 20);
			this->txtpares->TabIndex = 8;
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(297, 261);
			this->Controls->Add(this->txtpares);
			this->Controls->Add(this->button1);
			this->Controls->Add(this->Grid);
			this->Controls->Add(this->btnintroducir);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->txtnumero);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->txttamano);
			this->Controls->Add(this->btndesignar);
			this->Name = L"Form1";
			this->Text = L"Form1";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void btndesignar_Click(System::Object^  sender, System::EventArgs^  e) {
				  int tam;
			 tam=(System::Convert::ToInt32(txttamano->Text));
			 C.Settamano(tam);
			 Grid->RowCount=tam;

			 }
private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e) {

			txtpares->Text=marshal_as<String^>(C.calcularpar(C.Gettamano()));

		 }
private: System::Void btnintroducir_Click(System::Object^  sender, System::EventArgs^  e) {
			 float num;
			 num=(System::Convert::ToInt32(txtnumero->Text));
			 C.Setnumero(num,pos);
			 Grid->Rows[pos]->Cells[0]->Value=num;
			 pos++;
		 }
};
}

