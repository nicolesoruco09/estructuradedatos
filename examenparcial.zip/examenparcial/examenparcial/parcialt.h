#pragma once
#include <string>
#define K 20

using namespace std;

 class parcialt
{
private:
	int numero[K];
	int tamano;
public:
	parcialt(void);
	void Settamano(int tam);
    int Gettamano ();
	void Setnumero (int elem, int pos);
    int Getnumero (int pos );
	string calcularpar (int tam);

};

