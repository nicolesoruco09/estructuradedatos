#include "StdAfx.h"
#include "inter.h"


inter::inter(void)
{vec[N]=0;
tamano=0;
}
void inter::setnumero (int e, int pos)
{vec[pos]=e;
}
int inter::getnumero (int pos)
{ return vec[pos];
}
void inter::settamano (int tam)
{ tamano=tam;
}
int inter::gettamano ()
{return tamano;
}
void inter::calcular ()
{
	for (int i=0;i<=tamano/2;i++)
	{int aux=vec[i];
	vec[i]=vec[tamano-1-i];
	vec[tamano-1-i]=aux;
	}
}



