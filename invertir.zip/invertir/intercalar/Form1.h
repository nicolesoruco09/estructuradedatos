#pragma once
#include "inter.h"
#include "iostream"

namespace intercalar {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	inter A;
	int pos=0;

	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Button^  btndesignar;
	protected: 
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::TextBox^  txttamano;
	private: System::Windows::Forms::TextBox^  txtnumero;
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::Button^  button2;
	private: System::Windows::Forms::Button^  btninvertir;
	private: System::Windows::Forms::DataGridView^  Grid;

	private: System::Windows::Forms::DataGridViewTextBoxColumn^  numero;


	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->btndesignar = (gcnew System::Windows::Forms::Button());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->txttamano = (gcnew System::Windows::Forms::TextBox());
			this->txtnumero = (gcnew System::Windows::Forms::TextBox());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->button2 = (gcnew System::Windows::Forms::Button());
			this->btninvertir = (gcnew System::Windows::Forms::Button());
			this->Grid = (gcnew System::Windows::Forms::DataGridView());
			this->numero = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid))->BeginInit();
			this->SuspendLayout();
			// 
			// btndesignar
			// 
			this->btndesignar->Location = System::Drawing::Point(150, 29);
			this->btndesignar->Name = L"btndesignar";
			this->btndesignar->Size = System::Drawing::Size(67, 23);
			this->btndesignar->TabIndex = 0;
			this->btndesignar->Text = L"designar";
			this->btndesignar->UseVisualStyleBackColor = true;
			this->btndesignar->Click += gcnew System::EventHandler(this, &Form1::btndesignar_Click);
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(12, 34);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(42, 13);
			this->label1->TabIndex = 1;
			this->label1->Text = L"tamano";
			// 
			// txttamano
			// 
			this->txttamano->Location = System::Drawing::Point(53, 34);
			this->txttamano->Name = L"txttamano";
			this->txttamano->Size = System::Drawing::Size(91, 20);
			this->txttamano->TabIndex = 2;
			// 
			// txtnumero
			// 
			this->txtnumero->Location = System::Drawing::Point(53, 79);
			this->txtnumero->Name = L"txtnumero";
			this->txtnumero->Size = System::Drawing::Size(91, 20);
			this->txtnumero->TabIndex = 5;
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(12, 79);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(42, 13);
			this->label2->TabIndex = 4;
			this->label2->Text = L"numero";
			// 
			// button2
			// 
			this->button2->Location = System::Drawing::Point(150, 74);
			this->button2->Name = L"button2";
			this->button2->Size = System::Drawing::Size(67, 23);
			this->button2->TabIndex = 3;
			this->button2->Text = L"introducir";
			this->button2->UseVisualStyleBackColor = true;
			this->button2->Click += gcnew System::EventHandler(this, &Form1::button2_Click);
			// 
			// btninvertir
			// 
			this->btninvertir->Location = System::Drawing::Point(89, 105);
			this->btninvertir->Name = L"btninvertir";
			this->btninvertir->Size = System::Drawing::Size(64, 24);
			this->btninvertir->TabIndex = 6;
			this->btninvertir->Text = L"invertir";
			this->btninvertir->UseVisualStyleBackColor = true;
			this->btninvertir->Click += gcnew System::EventHandler(this, &Form1::btninvertir_Click);
			// 
			// Grid
			// 
			this->Grid->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->Grid->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(1) {this->numero});
			this->Grid->Location = System::Drawing::Point(32, 145);
			this->Grid->Name = L"Grid";
			this->Grid->Size = System::Drawing::Size(164, 110);
			this->Grid->TabIndex = 7;
			// 
			// numero
			// 
			this->numero->HeaderText = L"Column1";
			this->numero->Name = L"numero";
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(284, 280);
			this->Controls->Add(this->Grid);
			this->Controls->Add(this->btninvertir);
			this->Controls->Add(this->txtnumero);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->button2);
			this->Controls->Add(this->txttamano);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->btndesignar);
			this->Name = L"Form1";
			this->Text = L"Form1";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void button2_Click(System::Object^  sender, System::EventArgs^  e) {
			int numero;
			numero=System::Convert::ToInt32(txtnumero->Text);
			A.setnumero(numero,pos);
			Grid->Rows[pos]->Cells[0]->Value=numero;
			pos++;
			 }
private: System::Void btndesignar_Click(System::Object^  sender, System::EventArgs^  e) {
			 int tama;
			 tama=System::Convert::ToInt32(txttamano->Text);
			 A.settamano(tama);
			 Grid->RowCount=tama;
		 }
private: System::Void btninvertir_Click(System::Object^  sender, System::EventArgs^  e) {
			 A.calcular();
			 for (int i=0;i<A.gettamano();i++)

			 Grid->Rows[i]->Cells[0]->Value=A.getnumero(i);

		 }
};
}

