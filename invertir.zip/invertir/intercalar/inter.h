#pragma once
#include "iostream"
#define N 20

 class inter
{
private:
	int vec[N];
	int tamano;
public:
	inter(void);
	void setnumero (int e, int pos);
	int getnumero (int pos);
	void settamano (int tam);
	int gettamano ();
	void calcular ();

};

