#include "StdAfx.h"
#include "matrizz.h"


matrizz::matrizz(void)
{  V[N][M]=0;
}
void matrizz::Setfila (int f)
{fila=f;
}
int matrizz::Getfila ()
{return fila;
}
void matrizz::Setcolum (int c)
{columna=c;
}
int matrizz::Getcolum ()
{return columna;
}
void matrizz::insertar( int a, int x, int y)
{V[x][y]=a;
}
int matrizz::mostrar (int x, int y)
{return V[x][y];
}
int matrizz::sumadiagonal ( int x, int y)
{int s=0;
  for (int i=0;i<x;i++)
  {for (int j=0;j<y;j++)
  {if (i==j)
  {s=s+V[i][j];}}}
	return s;
}
int matrizz::suma ( int x, int y)
{int s=0;
  for (int i=0;i<x;i++)
  {for (int j=0;j<y;j++)
  {
  {s=s+V[i][j];}}}
	return s;
}