#pragma once
#include "matrizz.h"

namespace matricesbyme {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
matrizz A;
int posn=0;
int posm=0;

	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Button^  button1;
	protected: 
	private: System::Windows::Forms::Button^  button2;
	private: System::Windows::Forms::TextBox^  txtfila;
	private: System::Windows::Forms::TextBox^  txtcolum;


	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::TextBox^  txtelemento;

	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::Label^  label4;
	private: System::Windows::Forms::Label^  label5;
	private: System::Windows::Forms::TextBox^  txtmostrarfi;


	private: System::Windows::Forms::Label^  label6;
	private: System::Windows::Forms::DataGridView^  Grid;
	private: System::Windows::Forms::TextBox^  txtmostrarco;

	private: System::Windows::Forms::Label^  label7;
	private: System::Windows::Forms::Label^  label8;
	private: System::Windows::Forms::Button^  button3;
	private: System::Windows::Forms::TextBox^  txtmostrar;
	private: System::Windows::Forms::Button^  button4;
	private: System::Windows::Forms::TextBox^  txtsumad;
	private: System::Windows::Forms::Button^  button5;
	private: System::Windows::Forms::TextBox^  txtsuna;




	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->button2 = (gcnew System::Windows::Forms::Button());
			this->txtfila = (gcnew System::Windows::Forms::TextBox());
			this->txtcolum = (gcnew System::Windows::Forms::TextBox());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->txtelemento = (gcnew System::Windows::Forms::TextBox());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->txtmostrarfi = (gcnew System::Windows::Forms::TextBox());
			this->label6 = (gcnew System::Windows::Forms::Label());
			this->Grid = (gcnew System::Windows::Forms::DataGridView());
			this->txtmostrarco = (gcnew System::Windows::Forms::TextBox());
			this->label7 = (gcnew System::Windows::Forms::Label());
			this->label8 = (gcnew System::Windows::Forms::Label());
			this->button3 = (gcnew System::Windows::Forms::Button());
			this->txtmostrar = (gcnew System::Windows::Forms::TextBox());
			this->button4 = (gcnew System::Windows::Forms::Button());
			this->txtsumad = (gcnew System::Windows::Forms::TextBox());
			this->button5 = (gcnew System::Windows::Forms::Button());
			this->txtsuna = (gcnew System::Windows::Forms::TextBox());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid))->BeginInit();
			this->SuspendLayout();
			// 
			// button1
			// 
			this->button1->Location = System::Drawing::Point(184, 39);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(79, 26);
			this->button1->TabIndex = 0;
			this->button1->Text = L"definir";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &Form1::button1_Click);
			// 
			// button2
			// 
			this->button2->Location = System::Drawing::Point(192, 117);
			this->button2->Name = L"button2";
			this->button2->Size = System::Drawing::Size(80, 24);
			this->button2->TabIndex = 1;
			this->button2->Text = L"ingresar";
			this->button2->UseVisualStyleBackColor = true;
			this->button2->Click += gcnew System::EventHandler(this, &Form1::button2_Click);
			// 
			// txtfila
			// 
			this->txtfila->Location = System::Drawing::Point(80, 32);
			this->txtfila->Name = L"txtfila";
			this->txtfila->Size = System::Drawing::Size(84, 20);
			this->txtfila->TabIndex = 2;
			// 
			// txtcolum
			// 
			this->txtcolum->Location = System::Drawing::Point(80, 69);
			this->txtcolum->Name = L"txtcolum";
			this->txtcolum->Size = System::Drawing::Size(84, 20);
			this->txtcolum->TabIndex = 3;
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(12, 9);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(42, 13);
			this->label1->TabIndex = 4;
			this->label1->Text = L"tamano";
			// 
			// txtelemento
			// 
			this->txtelemento->Location = System::Drawing::Point(95, 117);
			this->txtelemento->Name = L"txtelemento";
			this->txtelemento->Size = System::Drawing::Size(69, 20);
			this->txtelemento->TabIndex = 5;
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(19, 39);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(25, 13);
			this->label2->TabIndex = 6;
			this->label2->Text = L"filas";
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(19, 72);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(52, 13);
			this->label3->TabIndex = 7;
			this->label3->Text = L"columnas";
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Location = System::Drawing::Point(36, 124);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(50, 13);
			this->label4->TabIndex = 8;
			this->label4->Text = L"elemento";
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Location = System::Drawing::Point(302, 52);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(41, 13);
			this->label5->TabIndex = 9;
			this->label5->Text = L"mostrar";
			// 
			// txtmostrarfi
			// 
			this->txtmostrarfi->Location = System::Drawing::Point(378, 32);
			this->txtmostrarfi->Name = L"txtmostrarfi";
			this->txtmostrarfi->Size = System::Drawing::Size(69, 20);
			this->txtmostrarfi->TabIndex = 10;
			// 
			// label6
			// 
			this->label6->AutoSize = true;
			this->label6->Location = System::Drawing::Point(12, 101);
			this->label6->Name = L"label6";
			this->label6->Size = System::Drawing::Size(44, 13);
			this->label6->TabIndex = 11;
			this->label6->Text = L"ingresar";
			// 
			// Grid
			// 
			this->Grid->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->Grid->Location = System::Drawing::Point(24, 165);
			this->Grid->Name = L"Grid";
			this->Grid->Size = System::Drawing::Size(247, 111);
			this->Grid->TabIndex = 12;
			// 
			// txtmostrarco
			// 
			this->txtmostrarco->Location = System::Drawing::Point(379, 71);
			this->txtmostrarco->Name = L"txtmostrarco";
			this->txtmostrarco->Size = System::Drawing::Size(67, 20);
			this->txtmostrarco->TabIndex = 13;
			// 
			// label7
			// 
			this->label7->AutoSize = true;
			this->label7->Location = System::Drawing::Point(337, 35);
			this->label7->Name = L"label7";
			this->label7->Size = System::Drawing::Size(20, 13);
			this->label7->TabIndex = 14;
			this->label7->Text = L"fila";
			// 
			// label8
			// 
			this->label8->AutoSize = true;
			this->label8->Location = System::Drawing::Point(326, 74);
			this->label8->Name = L"label8";
			this->label8->Size = System::Drawing::Size(47, 13);
			this->label8->TabIndex = 15;
			this->label8->Text = L"columna";
			// 
			// button3
			// 
			this->button3->Location = System::Drawing::Point(477, 45);
			this->button3->Name = L"button3";
			this->button3->Size = System::Drawing::Size(83, 26);
			this->button3->TabIndex = 16;
			this->button3->Text = L"mostrar";
			this->button3->UseVisualStyleBackColor = true;
			this->button3->Click += gcnew System::EventHandler(this, &Form1::button3_Click);
			// 
			// txtmostrar
			// 
			this->txtmostrar->Location = System::Drawing::Point(491, 94);
			this->txtmostrar->Name = L"txtmostrar";
			this->txtmostrar->Size = System::Drawing::Size(69, 20);
			this->txtmostrar->TabIndex = 17;
			// 
			// button4
			// 
			this->button4->Location = System::Drawing::Point(477, 165);
			this->button4->Name = L"button4";
			this->button4->Size = System::Drawing::Size(84, 26);
			this->button4->TabIndex = 18;
			this->button4->Text = L"sumadiagonal";
			this->button4->UseVisualStyleBackColor = true;
			this->button4->Click += gcnew System::EventHandler(this, &Form1::button4_Click);
			// 
			// txtsumad
			// 
			this->txtsumad->Location = System::Drawing::Point(379, 169);
			this->txtsumad->Name = L"txtsumad";
			this->txtsumad->Size = System::Drawing::Size(68, 20);
			this->txtsumad->TabIndex = 19;
			this->txtsumad->TextChanged += gcnew System::EventHandler(this, &Form1::textBox1_TextChanged);
			// 
			// button5
			// 
			this->button5->Location = System::Drawing::Point(493, 213);
			this->button5->Name = L"button5";
			this->button5->Size = System::Drawing::Size(67, 22);
			this->button5->TabIndex = 20;
			this->button5->Text = L"suma";
			this->button5->UseVisualStyleBackColor = true;
			this->button5->Click += gcnew System::EventHandler(this, &Form1::button5_Click);
			// 
			// txtsuna
			// 
			this->txtsuna->Location = System::Drawing::Point(379, 215);
			this->txtsuna->Name = L"txtsuna";
			this->txtsuna->Size = System::Drawing::Size(68, 20);
			this->txtsuna->TabIndex = 21;
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(637, 302);
			this->Controls->Add(this->txtsuna);
			this->Controls->Add(this->button5);
			this->Controls->Add(this->txtsumad);
			this->Controls->Add(this->button4);
			this->Controls->Add(this->txtmostrar);
			this->Controls->Add(this->button3);
			this->Controls->Add(this->label8);
			this->Controls->Add(this->label7);
			this->Controls->Add(this->txtmostrarco);
			this->Controls->Add(this->Grid);
			this->Controls->Add(this->label6);
			this->Controls->Add(this->txtmostrarfi);
			this->Controls->Add(this->label5);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->txtelemento);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->txtcolum);
			this->Controls->Add(this->txtfila);
			this->Controls->Add(this->button2);
			this->Controls->Add(this->button1);
			this->Name = L"Form1";
			this->Text = L"Form1";
			this->Load += gcnew System::EventHandler(this, &Form1::Form1_Load);
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e) {
				 int F=Convert::ToInt32(txtfila->Text);
				 int C=Convert::ToInt32(txtcolum->Text);
				 A.Setfila(F);
				 A.Setcolum(C);
				 Grid->RowCount=F;
				 Grid->ColumnCount=C;
			 }


private: System::Void button2_Click(System::Object^  sender, System::EventArgs^  e) {
		int E=Convert::ToInt32(txtelemento->Text);
			 A.insertar(E, posn, posm);
			 Grid->Rows[posn]->Cells[posm]->Value=E;
			 posm++;
			 if (posm==A.Getcolum())
			 { posm=0;
			    posn++;
			 }
			if (posn==A.Getfila()) 
			{MessageBox::Show("esta lleno");}
		}



private: System::Void button3_Click(System::Object^  sender, System::EventArgs^  e) {
		 int x=Convert::ToInt32(txtmostrarfi->Text);
		 int y=Convert::ToInt32(txtmostrarco->Text);
		 int E= A.mostrar(x-1,y-1);
		 txtmostrar->Text=Convert::ToString(E);
		 }

private: System::Void button4_Click(System::Object^  sender, System::EventArgs^  e) {
		 int E = A.sumadiagonal( A.Getfila(), A.Getcolum());
		 txtsumad->Text=Convert::ToString(E);
		 }

private: System::Void textBox1_TextChanged(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void Form1_Load(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void button5_Click(System::Object^  sender, System::EventArgs^  e) {
         int E = A.suma( A.Getfila(), A.Getcolum());
		 txtsuna->Text=Convert::ToString(E);



		 }
};
}

