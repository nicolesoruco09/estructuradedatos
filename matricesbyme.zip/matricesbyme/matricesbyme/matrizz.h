#pragma once
#define N 10
#define M 10

 class matrizz
{private:
  int V[N][M];
  int fila;
  int columna;
public:
	matrizz(void);
	void Setfila (int f);
	int Getfila ();
	void Setcolum (int c);
	int Getcolum ();
	void insertar( int a, int x, int y);
	int mostrar (int x, int y);
	int sumadiagonal ( int x, int y);
	int suma ( int x, int y);


};

